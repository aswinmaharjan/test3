#!/usr/bin/env python3
# Author:
# Date:
# Purpose: Function library for Test 3.

# write_csv function

    
    # Import the os and sys modules


    # Check if the namesFile doesn't exist


        # Exit the program with an error message


    # Check if the emailsFile doesn't exist


        # Exit the program with an error message


    # Check if the usersFile doesn't exist


        # Create the usersFile


    # Open the namesFile with read permission as namesData


        # Read the lines of the namesData file and store them in the list names


    # Open the emailsFile with read permission as emailsData


        # Read the lines of the emailsData file and store them in the list emails


    # Open the usersFile with append permission as file
    with open(usersFile, "a") as file:

        # Loop through the range of the length of the names list
        for each in range(len(names)):

            # Write the names and emails to the file
            file.write(names[each].strip() + "," + emails[each].strip() + "\n")

    # Close the namesData file
    namesData.close()

    # Close the emailsData file
    emailsData.close()

    # Close the file
    file.close()

# read_csv function


    # Open the file with read permission. Store it in the variable users.


    # Print the header
    print(f"{'Name':10}\t{'Email'}")

    # Use a for loop to loop through the lines in the users file
    for data in users:

        # Split the data by comma
        data = data.split(',')

        # Print the data with a fixed field width of 10 for the name (data 0) and no fixed field width for the email (data 1). Separate the name and email with a tab.

#!/usr/bin/env python3
# Author:
# Date:
# Purpose: Import the write_csv and read_csv functions from lib. Call each function.
# Usage: ./test3.py
# 

# Import the write_csv and read_csv functions from lib


# Call the write_csv function, passing it the arguments "names.dat", "emails.dat", and "users.csv"


# Call the read_csv function, passing it the argument "users.csv"
